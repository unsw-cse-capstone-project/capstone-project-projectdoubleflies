package com.mealmatch.demo.model;

public class User {

}
